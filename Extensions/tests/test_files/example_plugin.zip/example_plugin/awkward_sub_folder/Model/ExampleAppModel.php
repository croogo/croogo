<?php
class ExampleAppModel extends AppModel {

}
