<?php
class ExampleAppController extends AppController {

}
